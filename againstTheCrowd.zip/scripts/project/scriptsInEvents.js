import { fetchGameDetails, startGame, reportAchievement , closeGame, kick} from './ArcadeAPI.js';

// Start console function
import { ScreenLog } from './ScreenLog.js';


const scriptsInEvents = {

	async _arcadeapi_Event16_Act3(runtime, localVars)
	{
		fetchGameDetails(runtime);
	},

	async _arcadeapi_Event21_Act2(runtime, localVars)
	{
		startGame(runtime);
	},

	async _arcadeapi_Event25_Act1(runtime, localVars)
	{
		reportAchievement(runtime);
	},

	async _arcadeapi_Event44_Act1(runtime, localVars)
	{
		closeGame(runtime);
	},

	async _arcadeapi_Event48_Act1(runtime, localVars)
	{
		ScreenLog();
	},

	async _arcadeapi_Event49_Act1(runtime, localVars)
	{
		fetchGameDetails(runtime);
	},

	async _arcadeapi_Event50_Act1(runtime, localVars)
	{
		startGame(runtime);
	},

	async _arcadeapi_Event51_Act1(runtime, localVars)
	{
		reportAchievement(runtime);
	},

	async _arcadeapi_Event52_Act1(runtime, localVars)
	{
		kick(runtime);
	}

};

self.C3.ScriptsInEvents = scriptsInEvents;

