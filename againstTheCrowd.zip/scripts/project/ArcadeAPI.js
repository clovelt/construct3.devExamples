import * as ArcadeAPI_Configuration from './ArcadeAPI_Configuration.js';

// Debugging
import { TrackJS } from './t.js';
import { ScreenLog } from './ScreenLog.js';


//{GameURL}?sid=${SessionId}&lang=${rootStore.settingsStore.language}&clientId=${client_id}&machineId=${machineId}&token=${rootStore.idToken}

const GameURL = window.location.href;

// Create a URL object
const url = new URL(GameURL);

// Extract query parameters
const params = new URLSearchParams(url.search);

let clientId = params.get('clientId');
let language = params.get('lang');
let gameSessionID = params.get('sid');
let machineId = params.get('machineId');
let token = params.get('token');

let preview = false;
function checkPreview() {
	if (GameURL == "https://preview.construct.net/local.html") {
		preview = true;
		// Debug values
		clientId = 24;
		language = "en-US";
		gameSessionID = "9e555bd6-3dda-ee11-827a-12853b9039eb";
		machineId = 1400;
		token = "eyJhbGciOiJSUzI1NiIsImtpZCI6IjgwNzhkMGViNzdhMjdlNGUxMGMzMTFmZTcxZDgwM2I5MmY3NjYwZGYiLCJ0eXAiOiJKV1QifQ.eyJQbGF5ZXJJZCI6MTM0NjU2OTAsImlzcyI6Imh0dHBzOi8vc2VjdXJldG9rZW4uZ29vZ2xlLmNvbS9hcmNhZGVzcHJvYXBwIiwiYXVkIjoiYXJjYWRlc3Byb2FwcCIsImF1dGhfdGltZSI6MTcxMTU0NDgyNSwidXNlcl9pZCI6ImQ0VEVvYzJIS01nZXpYamtXOFlhUGhIelR0MTIiLCJzdWIiOiJkNFRFb2MySEtNZ2V6WGprVzhZYVBoSHpUdDEyIiwiaWF0IjoxNzExOTk5MjMzLCJleHAiOjE3MTIwMDI4MzMsImVtYWlsIjoicnlhbkBiYWJ5bG9ucGFyay5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6eyJlbWFpbCI6WyJyeWFuQGJhYnlsb25wYXJrLmNvbSJdfSwic2lnbl9pbl9wcm92aWRlciI6InBhc3N3b3JkIn19.FQrJDPs90ZE8Z-lc0t_DFSoc6qBN0sMKO2Pe2H7uPC6OCqKUsHtBYqorWh47PVTKEEHYp9ZxjDJvj8J4DTqXY_-Gx9KhvaU4L9oPSZKG3MvWhendVr75-wb6QwW7Zm9QA74Lrs9-Ig9EgsqvLcaj4r2QraDZRKEDHBfXvNKGya2tK0gJpOSg4cj079X0piMRUaiIJ6NWDZl-Og0Su-tBUV1d1bimoGvxaSjOpHjItrVkjhPP0D_KORm-k-3U21rvRKMA13Yzo0uBxcCoqt1UoxAme2j4JhNHma9t4Svon5X6kAAGhzOC6zsunBh1aMc6yZf0R5z5llQKqv3QUcy8tA";
	}
}
checkPreview();

let jsDictionary = {};

export function fetchGameDetails(runtime) {
	const url = ArcadeAPI_Configuration.GetGameDetailsURL;
    const headers = new Headers({
        'Authorization': 'session '+token,
        'Content-Type': 'application/json'
    });
    const body = JSON.stringify({
        ClientId: clientId,
        MachineId: machineId,
        Language: language
    });

    fetch(url, {
        method: 'POST',
        headers: headers,
        body: body
    })
    .then(response => {
        if (!response.ok) {
			throw new Error('Network response was not ok');
			kick(runtime);
        }
        return response.json();
    })
    .then(data => {
        console.log(`GameURL: ${GameURL}`);
		console.log(`Client ID: ${clientId}`);
		console.log(`Language: ${language}`);
		console.log(`Game Session ID: ${gameSessionID}`);
		console.log(`Machine ID: ${machineId}`);
		console.log(`Token: ${token}`);
		
		console.log(`GetGameDetails post: ${body}`);
		console.log(data);
		if (data.status === false) {
			kick(runtime);
		}
		storeResponseInDictionaries(runtime, data);
		runtime.callFunction("Arcade_UpdateLoaded");
    })
    .catch(error => {
		console.error('Error fetching game details:', error);
		kick(runtime);
    });
}

export function startGame(runtime) {
    const url = ArcadeAPI_Configuration.StartGameURL;
    const headers = new Headers({
        'Authorization': 'token '+token,
        'Content-Type': 'application/json'
    });
    const body = JSON.stringify({
        SessionId: gameSessionID,
		ClientId: clientId,
        Language: language
    });
		
    fetch(url, {
        method: 'POST',
        headers: headers,
        body: body
    })
    .then(response => {
        if (!response.ok) {
			throw new Error('Network response was not ok');
			kick(runtime);
        }
        return response.json();
    })
    .then(data => {
        console.log(`StartGame post: ${body}`);
		console.log(data);
		if (data.status === false) {
			kick(runtime);
		}
		storeResponseInDictionaries(runtime, data);
		runtime.callFunction("Arcade_StartLoaded");
    })
    .catch(error => {
		console.error('Error reporting game start:', error);
		kick(runtime);
    });
}

export function reportAchievement(runtime) {
	const url = ArcadeAPI_Configuration.EndGameURL;
	let score = runtime.globalVars.arcade_score;
	let level = runtime.globalVars.arcade_level;
	let gameID = jsDictionary["GameId"][0];
	
	//if (preview === true) { score = 100; }
	
	console.log(`Prehash: ${gameSessionID + gameID + score}`);
	generateSHA512Base64Hash(gameSessionID + gameID + score)
    .then(hash => {
        console.log(`Posthash: ${hash}`);
	
    	const headers = new Headers({
    	    'Authorization': 'token '+token,
    	    'Content-Type': 'application/json'
    	});
		const body = JSON.stringify({
			ClientId: clientId,
			SessionId: gameSessionID,
			GameId: gameID,
			Level: level,
			Score: score,
			Language: language,
			Hash: hash
    	});
	
    	fetch(url, {
    	    method: 'POST',
    	    headers: headers,
    	    body: body
    	})
    	.then(response => {
    	    if (!response.ok) {
				throw new Error('Network response was not ok');
    	    }
    	    return response.json();
    	})
    	.then(data => {
			console.log(`EndGame post: ${body}`);
			console.log(data);
			let winScreen;
			if (data.Achievement.IsReachedRewardLimit === true) {
				winScreen = "limit";
			}
			else if (data.Achievement.Rewards && data.Achievement.Rewards.length > 0) {
				winScreen = "youWon";
				data.Achievement.Rewards.forEach(reward => {
					runtime.callFunction("Arcade_SpawnPrize", reward.Name, reward.RewardId, reward.Amount, reward.Icon);
			    });
			}
			else {
				winScreen = "score";
			}
			runtime.globalVars.arcade_WinScreen = winScreen;
			runtime.callFunction("Arcade_UpdateAttemptEnd");
    	})
    	.catch(error => {
			console.error('Error reporting achievement:', error);
    	});
	})
}

// Stores data in a dictionaries, both JS and Construct 3 (arcade_Data).
function storeResponseInDictionaries(runtime, response) {
    const dictionary = runtime.objects.arcade_Data.getFirstInstance();	
    const dataMap = dictionary.getDataMap(); // Get the Map object from the Dictionary

    Object.keys(response).forEach(key => {
        const value = response[key];
        if (Array.isArray(value)) {
            value.forEach((item, index) => {
                Object.keys(item).forEach(subKey => {
                    const dictKey = `${key}_${index}_${subKey}`;
                    // Use the Map's set method to store the data
                    dataMap.set(dictKey, item[subKey]);
					jsDictionary[dictKey] = jsDictionary[dictKey] || [];
                    jsDictionary[dictKey].push(item[subKey]);
                });
            });
        } else {
            // Directly use the Map's set method for non-array values
            dataMap.set(key, value);
			jsDictionary[key] = jsDictionary[key] || [];
            jsDictionary[key].push(value);
        }
    });
	console.log(jsDictionary);
}

async function generateSHA512Base64Hash(data) {
    const encoder = new TextEncoder();
    const dataBuffer = encoder.encode(data);
    
    // Generate SHA-512 hash
    const hashBuffer = await crypto.subtle.digest('SHA-512', dataBuffer);
    
    // Convert the buffer to a Base64 string
    let hashBase64 = btoa(String.fromCharCode(...new Uint8Array(hashBuffer)));
    
    // Truncate to 86 characters and append '=='
    const truncatedBase64 = hashBase64.substring(0, 86) + '==';
    
    return truncatedBase64;
}

export function kick(runtime) {
	runtime.callFunction("Arcade_Kick");
}

export function closeGame(runtime) {
	try {
        var currentUrl = window.location.href;
    	var newUrl = currentUrl.includes('?') ? currentUrl + '&Close=true' : currentUrl + '?Close=true';
		
    	// Use HTML5 History API to change the URL without reloading the page
    	window.history.pushState({ path: newUrl }, '', newUrl);
    } catch(error) {
        console.error('Error adding close query, closing natively...', error);
		close();
    }
}

/* SHA256HashGenerator.js 1.0: https://github.com/BaseMax/SHA256HashGeneratorJS
 * SHA-256 implementation in JavaScript / Chris Veness 2002-2014 / MIT Licence */
"use strict";var Sha256={};Sha256.hash=function(f){f=f.utf8Encode();for(var $,x,a,e,t,_,c,r,o=[1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298],h=[1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225],n=Math.ceil(((f+="\x80").length/4+2)/16),S=Array(n),b=0;b<n;b++){S[b]=Array(16);for(var d=0;d<16;d++)S[b][d]=f.charCodeAt(64*b+4*d)<<24|f.charCodeAt(64*b+4*d+1)<<16|f.charCodeAt(64*b+4*d+2)<<8|f.charCodeAt(64*b+4*d+3)}S[n-1][14]=(f.length-1)*8/4294967296,S[n-1][14]=Math.floor(S[n-1][14]),S[n-1][15]=(f.length-1)*8&4294967295;for(var u=Array(64),b=0;b<n;b++){for(var i=0;i<16;i++)u[i]=S[b][i];for(var i=16;i<64;i++)u[i]=Sha256.σ1(u[i-2])+u[i-7]+Sha256.σ0(u[i-15])+u[i-16]&4294967295;$=h[0],x=h[1],a=h[2],e=h[3],t=h[4],_=h[5],c=h[6],r=h[7];for(var i=0;i<64;i++){var R=r+Sha256.Σ1(t)+Sha256.Ch(t,_,c)+o[i]+u[i],p=Sha256.Σ0($)+Sha256.Maj($,x,a);r=c,c=_,_=t,t=e+R&4294967295,e=a,a=x,x=$,$=R+p&4294967295}h[0]=h[0]+$&4294967295,h[1]=h[1]+x&4294967295,h[2]=h[2]+a&4294967295,h[3]=h[3]+e&4294967295,h[4]=h[4]+t&4294967295,h[5]=h[5]+_&4294967295,h[6]=h[6]+c&4294967295,h[7]=h[7]+r&4294967295}return Sha256.toHexStr(h[0])+Sha256.toHexStr(h[1])+Sha256.toHexStr(h[2])+Sha256.toHexStr(h[3])+Sha256.toHexStr(h[4])+Sha256.toHexStr(h[5])+Sha256.toHexStr(h[6])+Sha256.toHexStr(h[7])},Sha256.ROTR=function(f,$){return $>>>f|$<<32-f},Sha256.Σ0=function(f){return Sha256.ROTR(2,f)^Sha256.ROTR(13,f)^Sha256.ROTR(22,f)},Sha256.Σ1=function(f){return Sha256.ROTR(6,f)^Sha256.ROTR(11,f)^Sha256.ROTR(25,f)},Sha256.σ0=function(f){return Sha256.ROTR(7,f)^Sha256.ROTR(18,f)^f>>>3},Sha256.σ1=function(f){return Sha256.ROTR(17,f)^Sha256.ROTR(19,f)^f>>>10},Sha256.Ch=function(f,$,x){return f&$^~f&x},Sha256.Maj=function(f,$,x){return f&$^f&x^$&x},Sha256.toHexStr=function(f){for(var $,x="",a=7;a>=0;a--)x+=($=f>>>4*a&15).toString(16);return x},void 0===String.prototype.utf8Encode&&(String.prototype.utf8Encode=function(){return unescape(encodeURIComponent(this))}),void 0===String.prototype.utf8Decode&&(String.prototype.utf8Decode=function(){try{return decodeURIComponent(escape(this))}catch(f){return this}}),"undefined"!=typeof module&&module.exports&&(module.exports=Sha256),"function"==typeof define&&define.amd&&define([],function(){return Sha256});