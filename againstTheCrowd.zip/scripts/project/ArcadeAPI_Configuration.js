export const GetGameDetailsURL = "https://dev.arcadespro.com/ArcadesManager.WebApi/api/v2/mobile/GetGameDetails";
export const StartGameURL = "https://dev.arcadespro.com/ArcadesOnline.WebApi/v2/StartGame";
export const EndGameURL = "https://dev.arcadespro.com/ArcadesOnline.WebApi/v2/EndGame";